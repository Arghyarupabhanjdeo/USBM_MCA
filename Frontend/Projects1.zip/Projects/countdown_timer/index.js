let countdown;

function startCountdown() {
  const secondsInput = document.getElementById("secondsInput").value;
  const seconds = parseInt(secondsInput, 10);

  if (isNaN(seconds) || seconds <= 0) {
    alert("Please enter a valid number");
    return;
  }

  clearInterval(countdown);
  let timeLeft = seconds;

  document.getElementById("timer").textContent = timeLeft; // Initial display

  countdown = setInterval(() => {
    timeLeft--;

    if (timeLeft < 0) {
      clearInterval(countdown);
      document.getElementById("timer").textContent = "Time is up!";
    } else {
      document.getElementById("timer").textContent = timeLeft; // Update timer
    }
  }, 1000);
}
